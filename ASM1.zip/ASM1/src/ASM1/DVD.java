/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.Serializable;

public class DVD implements Serializable {
    private String title;
    private String Id;
    private String Authors;
    private int Year;
    private String Language;
    private String Subject;
    private int Status;
    private int Copies;
    private String Publication;

    public DVD(String ID, String title, String authors, int year, String Language, String Subject, String Publication, int Status, int Copies) {
        this.Id = ID;
        this.title = title;
        this.Authors = authors;
        this.Publication = Publication;
        this.Year = year;
        this.Language = Language;
        this.Subject = Subject;
        this.Status = Status;
        this.Copies = Copies;
    }

    public String getId() {
        return Id;
    }

    public void updateReturn() {
        Status++;
    }

    public void updateBorrow() {
        Status--;
    }

    public void PrintBeautiful() {
        System.out.printf("%s - %s   \n%s   - Published Year:%d - Published by: %s \nLanguage: %s - Subject: %s\nCurrent Available: %d, Total: %d \n", Id, title, Authors, Year, Publication, Language,Subject, Status, Copies);
    }

    @Override
    public String toString() {//overriding the toString() method
        return (Id + "-" + title + "-" + Authors + "-" + Year + "-" + Language + "-" + Subject + "-" + Publication + "-" + Status + "-" + Copies);
    }
}
