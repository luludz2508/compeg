/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Member implements Serializable {
    private String Id;
    private String Fullname;
    private String Phone;
    private String Email;
    private String Address;
    private Date ExpiredDate;
    private double chargedFee = 0;
    private int BorrowingBook = 0;
    private String Status;
    public Member(String Id, String Fullname, String phone, String Email, String Address, Date expiredDate) {
        this.Id = Id;
        this.Fullname = Fullname;
        this.Phone = phone;
        this.Email = Email;
        this.Address = Address;
        this.ExpiredDate = expiredDate;
    }

    public void setBorrows(double fee, int booksBorrowing) {
        chargedFee = fee;
        if (booksBorrowing==1){
        BorrowingBook ++;} else if (booksBorrowing==-1){
            BorrowingBook--;
        }
    }

    public double getChargedFee() {
        return chargedFee;
    }

    public boolean checkExpiredDate() {
        Date now = new Date();
        return ExpiredDate.before(now);
    }

    public int getBorrowingBook() {
        return BorrowingBook;
    }

    public String getId() {
        return Id;
    }

    public void printbeautiful() {
        DateFormat formatted = new SimpleDateFormat("dd MMM yyyy");
        if (checkExpiredDate()){
            Status="unAvailable";
        } else {Status="Available";}
        System.out.printf("%s  %s\nPhone: %s - Email: %s\nAddress: %s \nExpired Date: " + formatted.format(ExpiredDate) +"  -Account Status: %s"+ "\nCharged Fee:%.2f  Borrowing Book:%d", Id, Fullname, Phone, Email, Address,Status, chargedFee, BorrowingBook);
    }

    @Override
    public String toString() {//overriding the toString() method
        return (Id + "-" + Fullname + "-" + Phone + "-" + Email + "-" + Address+ "-" + Status + "-" + ExpiredDate + "-" + chargedFee + "-" + BorrowingBook);
    }
}
