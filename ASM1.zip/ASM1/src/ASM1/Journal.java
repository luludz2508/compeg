/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.Serializable;

public class Journal implements Serializable {
    private String title;
    private int Year;
    private String ISSN;
    private String Language;
    private String Subject;
    private int Status;
    private int Copies;
    private String Publication;

    public Journal(String ISSN, String title, int Year, String Language, String Subject, String Publication, int Status, int Copies) {
        this.title = title;
        this.Publication = Publication;
        this.Year = Year;
        this.ISSN = ISSN;
        this.Language = Language;
        this.Subject = Subject;
        this.Status = Status;
        this.Copies = Copies;
    }

    public String getISSN() {
        return ISSN;
    }

    public void updateReturn() {
        Status++;
    }

    public void updateBorrow() {
        Status--;
    }

    public void PrintBeautiful() {
        System.out.printf("%s - %s     \nPublished Year:%d - Published by: %s \nLanguage: %s - Subject: %s\nCurrent Available: %d, Total: %d \n", ISSN, title, Year, Publication, Language,Subject, Status, Copies);
    }

    @Override
    public String toString() {//overriding the toString() method
        return (ISSN + "-" + title + "-" + Year + "-" + Language + "-" + Subject + "-" + Publication + "-" + Status + "-" + Copies);
    }
}
