/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class
ItemList implements Serializable {
    private ArrayList<Book> Books = new ArrayList<Book>();
    private ArrayList<DVD> DVDs = new ArrayList<DVD>();
    private ArrayList<Journal> Journals = new ArrayList<Journal>();

    public boolean checkformat(String regex, String string) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(string);
        return matcher.matches();
    }

    public void loadBook() throws IOException, ClassNotFoundException {
        FileInputStream ItemFile = new FileInputStream("ASM1/Data/Books.txt");
        ObjectInputStream ItemScan = new ObjectInputStream(ItemFile);
        Books = (ArrayList<Book>) ItemScan.readObject();
        ItemScan.close();
    }

    public void loadJournal() throws IOException, ClassNotFoundException {
        FileInputStream ItemFile = new FileInputStream("ASM1/Data/Journals.txt");
        ObjectInputStream ItemScan = new ObjectInputStream(ItemFile);
        Journals = (ArrayList<Journal>) ItemScan.readObject();
        ItemScan.close();
    }

    public void loadDVD() throws IOException, ClassNotFoundException {
        FileInputStream ItemFile = new FileInputStream("ASM1/Data/DVDs.txt");
        ObjectInputStream ItemScan = new ObjectInputStream(ItemFile);
        DVDs = (ArrayList<DVD>) ItemScan.readObject();
        ItemScan.close();
    }

    public void LoadAll() throws IOException, ClassNotFoundException {
        loadBook();
        loadJournal();
        loadDVD();
    }


    public void addBook(String method) {
        // Printout require user to input each data field of BOOK *********
        Scanner input = new Scanner(System.in);
        String ISBN;
        if (method.equals("")) {
            System.out.print("ISBN: ");
            while (true) {
                ISBN = input.nextLine();
                if (checkformat("(ISBN[-]*(1[03])*[ ]*(: ){0,1})*(([0-9Xx][- ]*){13}|([0-9Xx][- ]*){10})", ISBN)) { // referenced from regexlib.com
                 ISBN=ISBN.replaceAll("-|ISBN|\\s","");
                    break;
                } else {
                    System.out.print("Wrong format! Again: ");
                }
            }
        } else {
            System.out.println("ISBN: " + method);
            ISBN = method;
        }
        System.out.print("Title: ");
        String title = input.nextLine();
        System.out.print("Edition: ");
        String Edition = input.nextLine();
        System.out.print("Authors: ");
        String Authors = input.nextLine();
        System.out.print("Year: ");
        int Year;
        while (true) {
            try {
                Year = input.nextInt();if (Year > 1900 && Year < 2099) {
                    break;
                }else {
                    System.out.print("Wrong format! Again: ");
                }
            } catch (Exception e){
                System.out.println("Wrong format. Again ");
            }
        }

        input.nextLine();
        System.out.print("Language: ");
    String Language = input.nextLine();
        System.out.print("Subject: ");
    String Subject = input.nextLine();
        System.out.print("Publication: ");
    String Publication = input.nextLine();
    int Status = 0;
        System.out.print("Copies: ");
    int Copies  ;
        while(true) {
        try {
            Copies = input.nextInt();
            break;
        } catch (Exception e) {
            System.out.println("Wrong format! Try again: ");
        }
    }
        if(Copies >0)

    {
        Status = Copies;
    }

    Book book = new Book(ISBN, title, Edition, Authors, Year, Language, Subject, Publication, Status, Copies);
        Books.add(book);
}

    public void addJournal(String method) {
        // Printout require user to input each data field of Journal *********
        Scanner input = new Scanner(System.in);
        String ISSN;
        if (method.equals("")) {
            System.out.print("ISSN: ");
            while (true) {
                ISSN = input.nextLine();
                if (checkformat("^[\\d]{4}[\\s-]{0,1}[\\d]{4}$", ISSN)) {
                    ISSN= ISSN.replaceAll("\\s|-", "");
                    break;
                } else {
                    System.out.print("Wrong format! Again: ");
                }
            }
        } else {
            System.out.println("ISSN: " + method);
            ISSN = method;
        }
        System.out.print("Title: ");
        String title = input.nextLine();
        System.out.print("Year: ");
        int Year;
        while (true) {
            try {
                Year = input.nextInt();
                if (Year > 1000 && Year < 2099) {
                    break;
                } else {
                    System.out.println("Wrong format. Try again!");
                }
            } catch (Exception e) {
                System.out.print("Wrong format! Again: ");
            }
        }
        input.nextLine();
        System.out.print("Language: ");
        String Language = input.nextLine();
        System.out.print("Subject: ");
        String Subject = input.nextLine();
        System.out.print("Publication: ");
        String Publication = input.nextLine();
        int Status = 0;
        System.out.print("Copies: ");
        int Copies ;
        while (true) {
            try {
                Copies = input.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Wrong format! Try again: ");
            }
        }

        if (Copies > 0) {
            Status = Copies;
        }
        Journal journal = new Journal(ISSN, title, Year, Language, Subject, Publication, Status, Copies);
        Journals.add(journal);
    }

    public void addDVD(String method) {

        // Printout require user to input each data field of DVD *********
        Scanner input = new Scanner(System.in);
        String Id = "";

        if (method.equals("0")) {
            System.out.print("ID: ");
            try {
                Id = input.nextLine();
            } catch (Exception e) {
                System.out.println("Wrong format! Try again: ");
            }
        } else {
            System.out.println("ID: " + method);
            Id = method;
        }
        System.out.print("Title: ");
        String title = input.nextLine();
        System.out.print("Authors: ");
        String Authors = input.nextLine();
        System.out.print("Year(int): ");
        int Year;
        while (true) {
            try {
                Year = input.nextInt();
                if (Year > 1000 && Year < 2099) {
                    break;
                } else {
                    System.out.print("Wrong format! Again: ");
                }
            }catch (Exception e){
                System.out.print("Wrong format! Again: ");
            }
        }
        input.nextLine();
        System.out.print("Language: ");
        String Language = input.nextLine();
        System.out.print("Subject: ");
        String Subject = input.nextLine();
        System.out.print("Publication: ");
        String Publication = input.nextLine();
        int Status = 0;
        System.out.print("Copies: ");
        int Copies ;
        while (true) {
            try {
                Copies = input.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Wrong format! Try again: ");
            }
        }
        if (Copies > 0) {
            Status = Copies;
        }
        DVD dvd = new DVD(Id, title, Authors, Year, Language, Subject, Publication, Status, Copies);
        DVDs.add(dvd);
    }


    public void addItem() {


        Scanner input = new Scanner(System.in);


        label:
        while (true) {
            System.out.print("1. Book  2.Journal  3.DVD  q.Exit\nChoose which Item do you want to add: ");
            String choice = input.nextLine();
            switch (choice) {
                case "1":
                    addBook("");
                    break;
                case "2":
                    System.out.println("You chose to add Journal to the item file. Please input each information of the Journal.");
                    addJournal("");
                    break;
                case "3":
                    System.out.println("You chose to add DVD to the item file. Please input each information of the DVD.");
                    addDVD("0");
                    break;
                case "q":
                    break label;
                default:
                    System.out.println("Wrong selection. Please try again!");
                    break;
            }
        }
    }

    public ArrayList<Book> getBookArray() {
        return Books;
    }

    public ArrayList<Journal> getJournalArray() {
        return Journals;
    }

    public ArrayList<DVD> getDvdArray() {
        return DVDs;
    }


    public void updateItem() {
        Scanner input = new Scanner(System.in);
        String answer = "1";
        int check = 0;
        while (!answer.equals("q")) {
            System.out.print("1.Book  2.Journal  3.DVD  q.Exit\nWhich Item do you want to update: ");

            answer = input.nextLine();
            switch (answer) {
                case "q":
                    break;
                case "1":
                    System.out.print("Input the ISBN code of the book to update information: ");
                    String bookChange = input.nextLine();
                    for (int i = 0; i < Books.size(); i++) {
                        if (Books.get(i).getISBN().toLowerCase().equals(bookChange.toLowerCase())) {
                            String Bookdeleted = Books.get(i).getISBN();
                            Books.remove(i);
                            System.out.println("Please add new information: ");
                            addBook(Bookdeleted);
                            check = 1;
                            break;
                        }
                    }
                    break;
                case "2":
                    System.out.print("Input the ISSN code of the journal to update information: ");
                    String journalChange = input.nextLine();
                    for (int i = 0; i < Journals.size(); i++) {
                        if (Journals.get(i).getISSN().equals(journalChange)) {
                            String JournalDeleted = Journals.get(i).getISSN();
                            Journals.remove(i);
                            System.out.println("Please add new information: ");
                            addJournal(JournalDeleted);
                            check = 1;
                            break;
                        }
                    }
                    break;
                case "3":
                    System.out.print("Input the ISSN code of the DVD to update information: ");
                    String DVDChange = input.nextLine();
                    for (int i = 0; i < DVDs.size(); i++) {
                        if (DVDs.get(i).getId().equals(DVDChange)) {
                            String DVDdeleted = DVDs.get(i).getId();
                            DVDs.remove(i);
                            System.out.println("Please add new information: ");
                            addDVD(DVDdeleted);
                            check = 1;
                            break;
                        }
                    }
                    break;
                default:
                    System.out.println("Wrong choice! Try again. ");
                    break;
            }
            if (check == 1) {
                System.out.println("You successfully updated the Item!");
            } else {
                System.out.println("The chosen Item is not existed!");
            }
        }
    }

    public void deleteItem() {
        Scanner input = new Scanner(System.in);
        String answer = "1";
        int check = 0;
        while (!answer.equals("q")) {
            System.out.println("1.Book 2.Journal 3.DVD q.Exit\nWhich Item do you want to remove");
            answer = input.nextLine();
            switch (answer) {
                case "q":
                    break;
                case "1":
                    if (Books.size() < 2) {
                        System.out.println("There must be at least one book in the List. Exiting...");
                        break;
                    }
                    System.out.print("Input the ISBN code of the book to remove: ");
                    String bookRemove = input.nextLine();
                    for (int i = 0; i < Books.size(); i++) {
                        if (Books.get(i).getISBN().equals(bookRemove)) {
                            Books.remove(i);
                            check = 1;
                            break;
                        }
                    }
                    break;
                case "2":
                    if (Journals.size() < 2) {
                        System.out.println("There must be at least one Journal in the List. Exiting...");
                        break;
                    }
                    System.out.print("Input the ISSN code of the journal to remove: ");
                    String journalRemove = input.nextLine();
                    for (int i = 0; i < Journals.size(); i++) {
                        if (Journals.get(i).getISSN().equals(journalRemove)) {
                            Journals.remove(i);
                            check = 1;
                            break;
                        }
                    }
                    break;
                case "3":
                    if (DVDs.size() < 2) {
                        System.out.println("There must be at least one DVD in the List. Exiting...");
                        break;
                    }
                    System.out.print("Input the ISSN code of the DVD to update information: ");
                    String DVDRemove = input.nextLine();
                    for (int i = 0; i < DVDs.size(); i++) {
                        if (DVDs.get(i).getId().equals(DVDRemove)) {
                            DVDs.remove(i);
                            check = 1;
                            break;
                        }
                    }
                    break;
                default:
                    System.out.println("Wrong choice! Try again. ");
                    break;
            }
            if (check == 1) {
                System.out.println("You successfully removed the Item !");
            } else {
                System.out.println("The chosen Item is not existed!");
            }
        }
    }

    public void searchItem(String searchKey) {
        int countdown;

        int counta = 0, countb = 0, countc = 0, page = 1;
        String request = "";
        Scanner in = new Scanner(System.in);
        while (!request.equals("q")) {
            countdown = 10;
            System.out.printf("\n----------------Books that match '%s'----------------\n", searchKey);
            for (int i = counta; i < Books.size() && countdown > 0; i++) {
                if (Books.get(i).toString().toLowerCase().matches(".*" + searchKey.toLowerCase() + ".*")) {
                    counta += 1;
                    countdown--;
                    System.out.println((counta) + ".");
                    Books.get(i).PrintBeautiful();
                    System.out.println();
                }
            }
            System.out.printf("----------------Journals that match '%s'----------------\n", searchKey);
            for (int i = countb; i < Journals.size() && countdown > 0; i++) {
                if (Journals.get(i).toString().toLowerCase().matches(".*" + searchKey.toLowerCase() + ".*")) {
                    countb += 1;
                    countdown--;
                    System.out.println((countb) + ".");
                    Journals.get(i).PrintBeautiful();
                    System.out.println();
                }
            }
            System.out.printf("----------------DVDs that match '%s'----------------\n", searchKey);
            for (int i = countc; i < DVDs.size() && countdown > 0; i++) {
                if (DVDs.get(i).toString().toLowerCase().matches(".*" + searchKey.toLowerCase() + ".*")) {
                    countc += 1;
                    countdown--;
                    System.out.println((countc) + ".");
                    DVDs.get(i).PrintBeautiful();
                    System.out.println();
                }
            }
            System.out.println();
            if (page == 1) {
                System.out.printf("| %d |========================================================================(n)=>\n\nPress n to the next page\nPress q to exit", page);

            } else if (countdown != 0) {
                System.out.printf("<=(p)========================================================================| %d |\n\nPress p to the previous page\nPress q to exit", page);

            } else {
                System.out.printf("<=(p)====================================| %d |====================================(n)=>\n\nPress p to the previous page, n to the next page\nPress q to exit", page);

            }
            while (true) {
                request = in.nextLine().toLowerCase();
                if (request.equals("q")) {
                    break;
                }
                if (request.equals("p")) {

                    if (page == 1) {
                        System.out.println("Currently on the first page, try again.");

                    } else {
                        page--;
                        countdown = 20 - countdown;
                        if (countc >= countdown) {
                            countc = countc - countdown;
                        } else {
                            countdown = countdown - countc;
                            countc = 0;
                            if (countb >= countdown) {
                                countb = countb - countdown;
                            } else {
                                countdown = countdown - countb;
                                countb = 0;
                                if (counta >= countdown) {
                                    counta = counta -  countdown;
                                } else {
                                    counta = 0;
                                }
                            }
                        }
                        break;
                    }

                } else if (request.equals("n")) {
                    if (countdown == 0) {
                        page++;
                        break;
                    }
                    if ((counta + countb + countc) == (Books.size() + Journals.size() + DVDs.size())) {
                        System.out.println("There is no other item to find");
                        counta = 0;
                        countb = 0;
                        countc = 0;
                    }
                } else {
                    System.out.print("Wrong choice. Please choose p:previous page, n:next page or q:exit");
                }
            }
            System.out.println("Finished Finding ");
            System.out.println("_______________________________________________________________________________________________________________________________________________________");
        }
    }

    public void saveALL() throws IOException {
        FileOutputStream bookFile = new FileOutputStream("ASM1/Data/Books.txt");
        FileOutputStream JournalFile = new FileOutputStream("ASM1/Data/Journals.txt");
        FileOutputStream DVDFile = new FileOutputStream("ASM1/Data/DVDs.txt");
        ObjectOutputStream outputBook = new ObjectOutputStream(bookFile);
        ObjectOutputStream outputJournal = new ObjectOutputStream(JournalFile);
        ObjectOutputStream outputDVD = new ObjectOutputStream(DVDFile);
        outputBook.writeObject(Books);
        outputJournal.writeObject(Journals);
        outputDVD.writeObject(DVDs);
        outputBook.flush();
        outputJournal.flush();
        outputDVD.flush();
        outputBook.close();
        outputJournal.close();
        outputDVD.close();
    }
}
