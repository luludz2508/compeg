/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;


import java.util.*;
import java.io.IOException;


public class ASM1 {
    public void DisplayMenu() throws IOException, ClassNotFoundException {
        String choice;
        Scanner input = new Scanner(System.in);
        ItemList iList = new ItemList();
        MemberList mList = new MemberList();
        BorrowList bList = new BorrowList();

        String keyword;
        boolean loop = true;

        while (loop) {
            // load for section storage
            iList.LoadAll();
            mList.loadMember();
            bList.loadList();
            bList.loadBorrow();
            System.out.print("Welcome to QuickLib!!!\n" +
                    "********************************\n" +
                    "1. Search items by keywords\n" +
                    "2. Add new item\n" +
                    "3. Update item info\n" +
                    "4. Search members by keywords\n" +
                    "5. Register new member\n" +
                    "6. Update member info\n" +
                    "7. Borrow items\n" +
                    "8. Return items\n" +
                    "9. Save data\n" +
                    "10. Quit\n" +
                    "**************************************\n" +
                    "Enter a function (1-10): ");
            choice = input.nextLine();
            if (!choice.equals("0")) {
                label:
                switch (choice) {
                    case "1":
                        System.out.print("'q'to quit. Keyword:\n");
                        keyword = input.nextLine();
                        iList.searchItem(keyword);
                        break;
                    case "2":
                        iList.addItem();
                        iList.saveALL();
                        break;
                    case "3":
                        System.out.print("1.Update Item  2.Delete Item  q.Quit\nChoice: ");
                        String answer = input.nextLine();
                        switch (answer) {
                            case "q":
                                break label;
                            case "1":
                                iList.updateItem();
                                break;
                            case "2":
                                iList.deleteItem();
                                break;
                        }
                        iList.saveALL();
                        break;
                    case "4":
                        System.out.print("'q'to quit. Keyword:");
                        String searchKey = input.nextLine();
                        mList.searchMember(searchKey);
                        break;
                    case "5":
                        System.out.println("Please input below information to add Member!");
                        mList.addMember("");
                        mList.saveMembers();
                        break;
                    case "6":
                        System.out.print("1.Update Member  2.Delete Member  q.Quit\nChoice: ");
                        String ans = input.nextLine();
                        switch (ans) {
                            case "q":
                                break label;
                            case "1":
                                mList.updateMember();
                                break;
                            case "2":
                                mList.deleteMember();
                                break;
                        }
                        mList.saveMembers();
                        break;
                    case "7":
                        bList.Borrows();
                        bList.SaveBorrows();
                        break;
                    case "8":
                        bList.returnBorrows();
                        bList.SaveBorrows();
                        break;
                    case "9":

                        System.out.println("Saved Successfully");
                        break;
                    case "10":
                        System.out.println("Exiting...");
                        loop = false;
                        break;
                    default:
                        System.out.println("Wrong choice. Please try again!");
                }
            }
        }
    }
       public static void main(String[] args) throws IOException, ClassNotFoundException {
        ASM1 asm1=new ASM1();
        asm1.DisplayMenu();
    }
}
