/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MemberList implements Serializable {
    private ArrayList<Member> Members = new ArrayList<Member>();
    private ArrayList<borrowRecord> Records = new ArrayList<borrowRecord>();

    public void loadMember() throws IOException, ClassNotFoundException {
        FileInputStream ItemFile = new FileInputStream("ASM1/Data/Members.txt");
        ObjectInputStream ItemScan = new ObjectInputStream(ItemFile);
        Members = (ArrayList<Member>) ItemScan.readObject();
        ItemScan.close();

        ObjectInputStream borrowScan = new ObjectInputStream(new FileInputStream("ASM1/Data/BorrowRecords.txt"));
        Records = (ArrayList<borrowRecord>) borrowScan.readObject();
        ItemScan.close();
    }

    public boolean checkformat(String regex, String string) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(string);
        return matcher.matches();
    }

    public void addMember(String method) {
        // Printout require user to input each data field of Member *********
        String Id;
        Scanner input = new Scanner(System.in);
        if (method.equals("")) {
            System.out.print("Id (Passport- B/C + 7 digits or Driver license- 12digits): ");
            while (true) {
                Id = input.nextLine();
                if (checkformat("^[BC][0-9]{7}$", Id) || checkformat("^[0-9]{12}$", Id)) {
                    break;
                } else {
                    System.out.print("Wrong format! Again:");
                }
            }
        } else {
            Id = method;
        }
        System.out.print("Full Name: ");
        String FullName = input.nextLine();
        System.out.print("Phone number (9-13 digits): ");
        String Phone;
        while (true) {
            Phone = input.nextLine();
            if (checkformat("^0[0-9\\s.-]{9,13}$", Phone)) {
                break;
            } else {
                System.out.print("Wrong format! Again:");
            }
        }
        System.out.print("Email: ");
        String Email;
        while (true) {
            Email = input.nextLine();
            if (checkformat("^^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", Email)) { // referenced from regexlib.com
                break;
            } else {
                System.out.print("Wrong format! Again:");
            }
        }

        System.out.print("Address: ");
        String Address = input.nextLine();
        // Scan date
        Date ExpiredDate;
        while (true) {
            System.out.print("Expired Date (dd/mm/yyyy):");
            String Datescanned = input.nextLine();
            DateFormat formatted = new SimpleDateFormat("dd/MM/yyyy");
            try {
                ExpiredDate = formatted.parse(Datescanned);
                break;
            } catch (ParseException e) {
                System.out.println("Wrong format");
            }
        }
        Member Member = new Member(Id, FullName, Phone, Email, Address, ExpiredDate);
        Members.add(Member);
    }

    public void updateMember() {
        int checkSuccess = 0;
        int loops = 1;
        Scanner input = new Scanner(System.in);
        while (loops != 0) {
            System.out.print("Please input the member ID that you want to update: ");
            String IDchange = input.nextLine();
            for (int i = 0; i < Members.size(); i++) {
                if (Members.get(i).getId().equals(IDchange)) {
                    checkSuccess = 1;
                    String deletedMember = Members.get(i).getId();
                    Members.remove(i);
                    addMember(deletedMember);

                    break;
                }
            }
            if (checkSuccess == 1) {
                System.out.printf("Updated Member %s successfully!", IDchange);
                loops = 0;
            } else {
                System.out.print("The input Member is not existed!\nChoose 1 to try again, 0 to exit:");
                loops = input.nextInt();
            }
        }
    }

    public void deleteMember() {
        Scanner input = new Scanner(System.in);
        int answer = 1, check = 0;
        while (answer != 0) {
            System.out.print("Input the Id of the member to be removed:");
            String memberRemove = input.nextLine();
            for (int i = 0; i < Members.size(); i++) {
                if (Members.get(i).getId().equals(memberRemove)) {
                    Members.remove(i);
                    check = 1;
                    break;
                }
            }
            if (check == 1) {
                System.out.println("You successfully removed the Member !");
                answer = 0;
            } else {
                System.out.print("The chosen member is not existed!\n Choose 1 to try again, 0 to exit: ");
                answer = input.nextInt();
            }
        }
    }

    public ArrayList<Member> getMemberArray() {
        return Members;
    }

    public void searchMember(String searchKey) {

        Scanner input = new Scanner(System.in);
        int count = 0, countdown;
        int loop = 0, page = 1;
        while (loop == 0) {
            countdown = 10;
            System.out.printf("----------------Members that match '%s'----------------\n", searchKey);
            for (int i = count; i < Members.size() && countdown > 0; i++) {
                if (Members.get(i).toString().matches(".*" + searchKey + ".*")) {
                    countdown--;
                    count++;
                    System.out.println((count) + ".");
                    Members.get(i).printbeautiful();
                    System.out.println("\nBorrowing Item: ");
                    for (borrowRecord record : Records) {
                        if (record.getID(1).toLowerCase().equals(Members.get(i).getId().toLowerCase())) {
                            System.out.println(record.getBorrows());
                        }
                    }

                    System.out.println();
                }
            }
            if (page == 1) {
                System.out.printf("| %d |========================================================================(n)=>\nPress n to the next page\nPress q to exit", page);

            } else if (countdown != 0) {
                System.out.printf("<=(p)========================================================================| %d |\nPress p to the previous page\nPress q to exit", page);

            } else {
                System.out.printf("<=(p)====================================| %d |====================================(n)=>\nPress p to the previous page, n to the next page\nPress q to exit", page);

            }
            while (true) {
                String choice = input.nextLine();
                if ("q".equals(choice)) {
                    loop = 1;
                    break;
                } else if ("n".equals(choice)) {
                    if (count < Members.size()) {
                        page++;
                        break;
                    } else if (page == 1) {
                        System.out.println("You are on the first page. Choose 0 to exit or 'n' to the next page");
                    } else {
                        System.out.println("There is no other members.Choose 0 to exit or 'p' to the previous page");
                    }
                } else if ("p".equals(choice)) {
                    if (page == 1) {
                        count = 0;
                    } else {
                        count = count - 10 - (10 - countdown);
                        page--;
                    }
                    break;
                } else {
                    System.out.println("Invalid, choose again!");
                }
            }
            System.out.println("Finished Finding ");
            System.out.println("_______________________________________________________________________________________________________________________________________________________");


        }
    }

    public void saveMembers() throws IOException {
        FileOutputStream MemberFile = new FileOutputStream("ASM1/Data/Members.txt");
        ObjectOutputStream outputMember = new ObjectOutputStream(MemberFile);
        outputMember.writeObject(Members);
        outputMember.flush();
        outputMember.close();
    }
}
