/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BorrowList implements Serializable {
    private Date borrowDate, deadlineDate;
    private ArrayList<borrowRecord> Records = new ArrayList<borrowRecord>();
    ArrayList<Book> Books = new ArrayList<Book>();
    ArrayList<Journal> Journals = new ArrayList<Journal>();
    ArrayList<DVD> DVDs = new ArrayList<DVD>();
    ArrayList<Member> Members = new ArrayList<Member>();

    public void loadBorrow() throws IOException, ClassNotFoundException {
        FileInputStream ItemFile = new FileInputStream("ASM1/Data/BorrowRecords.txt");
        ObjectInputStream ItemScan = new ObjectInputStream(ItemFile);
        Records = (ArrayList<borrowRecord>) ItemScan.readObject();
        ItemScan.close();
    }

    public void loadList() throws IOException, ClassNotFoundException {
        MemberList memList = new MemberList();
        memList.loadMember();
        Members = memList.getMemberArray();

        ItemList itemList = new ItemList();
        itemList.LoadAll();
        Books = itemList.getBookArray();

        Journals = itemList.getJournalArray();

        DVDs = itemList.getDvdArray();
    }



    public void Borrows() {
        boolean check = false, checkItem = false;

        Scanner input = new Scanner(System.in);

        String idInput, Item = null;
        while (true) {
            System.out.print("Input the member Id, 'q' to quit:");
            idInput = input.nextLine();
            if (idInput.equals("q")) {
                break;
            }
            for (Member member : Members) {
                if (member.getId().toLowerCase().equals(idInput.toLowerCase())) {
                    if (member.getChargedFee() != 0) {
                        System.out.printf("Member need to pay %.2f to borrow more items. \nPay now? 1.Yes  2.No :",member.getChargedFee());
                        String payFee =input.nextLine();
                        if (payFee.equals("1")){
                            member.setBorrows(0, 0);
                        } else if (payFee.equals("2")){
                            break;
                        } else {
                            System.out.println("Wrong format");
                        }
                        break;
                    }
                    if (member.getBorrowingBook() == 5) {
                        System.out.println("You are currently borrowing 5 items, you are not allowed to borrow anymore!");
                        break;
                    }
                    if (member.checkExpiredDate()) {
                        System.out.println("Member ID expired!");
                        break;
                    }
                    check = true;
                    member.setBorrows(0,1);
                    break;
                }
            }
            if (check) {
                break;
            } else {
                System.out.println(idInput + " is not allowed to borrow Item");
            }
        }
        //Borrow Item
        String chosenItem = null;
        if (check) {
            while (true) {
                System.out.print("1.Book  2.Journal  3.DVD  \nWhich Item to borrow: ");
                chosenItem = input.nextLine();
                switch (chosenItem) {
                    case "1":
                        System.out.print("Input Book Id: ");
                        Item = input.nextLine();
                        for (Book book : Books) {
                            if (book.getISBN().toLowerCase().equals(Item.toLowerCase())) {
                                checkItem = true;
                                break;
                            }
                        }
                        break;
                    case "2":
                        System.out.print("Input Journal Id: ");
                        Item = input.nextLine();
                        for (Journal journal : Journals) {
                            if (journal.getISSN().toLowerCase().equals(Item.toLowerCase())) {
                                checkItem = true;
                                break;
                            }
                        }
                        break;
                    case "3":
                        System.out.print("Input DVD Id: ");
                        Item = input.nextLine();
                        for (DVD dvd : DVDs) {
                            String id = String.valueOf(dvd.getId());
                            if (id.toLowerCase().equals(Item.toLowerCase())) {
                                checkItem = true;
                                break;
                            }
                        }
                        break;
                    default:
                        System.out.println("Wrong choice, try again:");
                }
                if (checkItem) {

                    break;
                } else {
                    System.out.println("Invalid. Try again.");
                }
            }
            //Borrow Date

            while (true) {
                boolean checking = false;
                String Datescanned = null;
                System.out.print("Borrow Date (dd/mm/yyyy):");
                while (!checking) {
                    Datescanned = input.nextLine();
                    Pattern pattern = Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{4}$");
                    Matcher matcher = pattern.matcher(Datescanned);
                    checking = matcher.matches();

                    if (!checking) {
                        System.out.println("Wrong format! Try again!");
                    }
                }
                DateFormat formatted = new SimpleDateFormat("dd/MM/yyyy");

                try {
                    borrowDate = formatted.parse(Datescanned);
                    switch (chosenItem) {
                        case "1": {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(borrowDate);
                            cal.add(Calendar.DATE, 14);
                            deadlineDate = cal.getTime();
                            break;
                        }
                        case "2":
                        case "3": {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(borrowDate);
                            cal.add(Calendar.DATE, 7);
                            deadlineDate = cal.getTime();
                            break;
                        }
                    }
                    break;
                } catch (ParseException e) {
                    System.out.println("Wrong format");
                }
            }
        }
        if (check) {
            String category = null;
            switch (chosenItem) {
                case "1":
                    category = "Book";
                    break;
                case "2":
                    category = "Journal";
                    break;
                case "3":
                    category = "DVD";
                    break;
            }
            switch (chosenItem) {
                case "1":
                    for (Book book : Books) {
                        if (book.getISBN().toLowerCase().equals(Item.toLowerCase())) {
                            book.updateBorrow();
                            break;
                        }
                    }
                case "2":
                    for (Journal journal : Journals) {
                        if (journal.getISSN().toLowerCase().equals(Item.toLowerCase())) {
                            journal.updateBorrow();
                            break;
                        }
                    }
                case "3":
                    for (DVD dvd : DVDs) {
                        if (dvd.getId().toLowerCase().equals(Item.toLowerCase())) {
                            dvd.updateBorrow();
                            break;
                        }
                    }

                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + chosenItem);
            }
            borrowRecord record = new borrowRecord(borrowDate, deadlineDate, idInput, Item, category);

            Records.add(record);

        }

    }


    public void returnBorrows() {
        Scanner input = new Scanner(System.in);
        String returnID;

        System.out.print("Borrowing member:\n");
        for (borrowRecord aYY : Records) {
            System.out.println(aYY.toString());
        }
        System.out.println();
        while (true) {
            System.out.print("Input the ID of member returning, 'q' to quit: ");
            returnID = input.nextLine();
            if (returnID.equals("q")) {
                break;
            }
            String returnItem;
            for (borrowRecord record : Records) {
                if (record.getID(1).equals(returnID.toLowerCase())) {

                    System.out.print("\nInput Item ID:");
                    returnItem = input.nextLine();
                    Date returnDate = null;
                    for (borrowRecord returning : Records) {
                        if (returning.getID(2).toLowerCase().equals(returnItem.toLowerCase()) && returning.getID(1).toLowerCase().equals(returnID.toLowerCase())
                        ) {
                            String Datescanned;
                            System.out.print("Return Date (dd/mm/yyyy):");
                        try {
                            Datescanned = input.nextLine();
                            DateFormat formatted = new SimpleDateFormat("dd/MM/yyyy");
                            returnDate = formatted.parse(Datescanned);
                            Records.remove(returning);

                        } catch (ParseException a){
                            System.out.println("Wrong format.Again!");
                        }
                            // Update member
                            for (Member member : Members) {
                                if (member.getId().toLowerCase().equals(returnID)) {
                                    assert returnDate != null;
                                    member.setBorrows(returning.getFee(returnDate),   -1);
                                    break;
                                }
                            }
                            // Update item
                            switch (returning.getCategory().toLowerCase()) {
                                case "Book":
                                    for (Book book : Books) {
                                        if (book.getISBN().toLowerCase().equals(returnItem.toLowerCase())) {
                                            book.updateReturn();
                                        }
                                    }
                                    break;
                                case "Journal":
                                    for (Journal Journal : Journals) {
                                        if (Journal.getISSN().toLowerCase().equals(returnItem.toLowerCase())) {
                                            Journal.updateReturn();
                                        }
                                    }
                                    break;
                                case "DVD":
                                    for (DVD DVD : DVDs) {
                                        if (DVD.getId().toLowerCase().equals(returnItem.toLowerCase())) {
                                            DVD.updateReturn();
                                        }
                                    }
                                    break;
                            }


                                System.out.println("Successfully Returned");



                        }
                        break;
                    }
                    break;
                }
            }
        }
    }

    public void SaveBorrows() throws IOException {
        //save Borrows
        FileOutputStream BorrowFile = new FileOutputStream("ASM1/Data/BorrowRecords.txt");
        ObjectOutputStream outputBorrow = new ObjectOutputStream(BorrowFile);
        outputBorrow.writeObject(Records);
        outputBorrow.flush();
        outputBorrow.close();
        //save Items
        FileOutputStream bookFile = new FileOutputStream("ASM1/Data/Books.txt");
        FileOutputStream JournalFile = new FileOutputStream("ASM1/Data/Journals.txt");
        FileOutputStream DVDFile = new FileOutputStream("ASM1/Data/DVDs.txt");
        ObjectOutputStream outputBook = new ObjectOutputStream(bookFile);
        ObjectOutputStream outputJournal = new ObjectOutputStream(JournalFile);
        ObjectOutputStream outputDVD = new ObjectOutputStream(DVDFile);
        outputBook.writeObject(Books);
        outputJournal.writeObject(Journals);
        outputDVD.writeObject(DVDs);
        outputBook.flush();
        outputJournal.flush();
        outputDVD.flush();
        outputBook.close();
        outputJournal.close();
        outputDVD.close();
        //save Member
        FileOutputStream MemberFile = new FileOutputStream("ASM1/Data/Members.txt");
        ObjectOutputStream outputMember = new ObjectOutputStream(MemberFile);
        outputMember.writeObject(Members);
        outputMember.flush();
        outputMember.close();
    }
}
