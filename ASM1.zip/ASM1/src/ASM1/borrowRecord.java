/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2020B
  Assessment: Assignment 1
  Author: Nguyen Thanh Luan
  ID: s3757937
  Created  date: 02/08/2020
  Last modified: 09/08/2020
  Acknowledgement: w3school.com, regexlib.com.
*/
package ASM1;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

public class borrowRecord implements Serializable {
    private Date borrowDate, deadlineDate;
    private String memberID, itemID, category;

    public borrowRecord(Date borrowdate, Date deadlinedate, String memberID, String itemID,String category) {
        this.borrowDate = borrowdate;
        this.deadlineDate = deadlinedate;
        this.memberID = memberID;
        this.itemID = itemID;
        this.category=category;
    }

    public String getID(int choice) {
        String id = null;
        if (choice == 1) {
            id = memberID;
        } else if (choice == 2) {
            id = itemID;
        }
        return id;
    }

    public double getFee(Date returnDate) {
        LocalDate date1 = deadlineDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate date2 = returnDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        Period period = Period.between(date1, date2);
        int days = period.getDays();
        return 0.1 * days;
    }

    public String getCategory(){
        return category;
    }
    public String getBorrows(){
        DateFormat formatted = new SimpleDateFormat("dd MMM yyyy");
        return ( " ItemID: " + itemID +"- Category: " +category + "- Borrowed Day: " + formatted.format(borrowDate) + "- Deadline Day:" + formatted.format(deadlineDate));
    }
    @Override
    public String toString() {//overriding the toString() method
        DateFormat formatted = new SimpleDateFormat("dd MMM yyyy");
        return ("MemberID: "+memberID + "- ItemID: " + itemID+"- Category: " +category + "- Borrowed Day: " + formatted.format(deadlineDate) + "- Deadline Day:" + formatted.format(deadlineDate));
    }
}
