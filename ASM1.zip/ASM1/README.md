RMIT University Vietnam
Course: INTE2512 Object-Oriented Programming
Semester: 2019C
Assessment name: Assignment 1
Name: Nguyen Thanh Luan 
ID: S3757937

1. INTRODUCTION
This software is designed as a quick library software which is used to manage libarary items, members and their borrowing items.

2. FEATURES
    1. Search current items of the library. This function will show only 10 items each page and search by the keyword from the user. The user can change page by press 'n' to next and 'p' to the previous page. 'q' to quit.

    2. Add item to the library source. User will be required to choose which category to add contains "Book","Journal","DVD". And then input information of the item chose.
    
    3. Update an item added to the library. Choose 1 to update an added one by ID. Choose 2 to definitely delete the item.
    
    4. Search Members by the keyword given by the user. 10 members will be shown on each page as well as their current borrows. The user can change page by press 'n' to next and 'p' to the previous page. 'q' to quit.
    
    5. Add new member of the library. Choose 1 to update an added one by ID. Choose 2 to definitely delete the member.
    
    6. Update information of the member, choose 1 to update the information excepts input ID, choose 2 to delete the Member that match the ID.
    
    7. Borrow the Item from the library. Initially, Input the ID to check is valid to borrow Item or not (Not owed any fee, total books borrowed not exceed 4 books,expierd date of member id is not reached ). If valid, require user to choose category and then input item ID as well as the borrow date. The program calculates the deadline date of the borrow and save to the data storage. The number of item available and borrowing item of the user also be modified.
    
    8. Return book to the library. The program will show list of the user and their borrows. Program requires user to input their if and id of the returning book as well as the return date. The program will calculate the charge fee base on the gap between deadline date and return date, then add charge fee to the member information. Deadline of the book item is 14 days from the borrow date, when it is 7 days for journal and DVD items.
    
    9. Save the current data to the default text and then back to the menu, continue running the program.

    10. Save the current data to the default text and then quit the program.

3. DESIGN
    Below is the map of the files:
|ASM1
    |--ASM1.iml
    |--README.md
    |.idea
    |doc
        |--ClassDiagram.pdf
        |--WorkBreakdownStructure.pdf
    |out
        |production
    |src
        |ASM1
            |Data
                |--Book.txt
                |--BorrowRecords.txt
                |--DVDs.txt
                |--Journals.txt
                |--Members.txt
            |--ASM1.java (main function)
            |--Book.java
            |--BorrowList.java
            |--borrowRecord.java
            |--DVD.java
            |--ItemList.java
            |--Journal.java
            |--Member.java
            |--MemberList.java

    There are 3 main object of the program. Items, member, borrowing record. Items include 3 objects which are Book, Journal, DVD. borrowing record is created based on the key attributes of the items and member. My data is saved to the default text file by file inputStream-ouputStream built-in function which helps me do not need to save data in string form. The overall design of the Program can by explained by my dropdown diagram. The detailed Object, Function and data field are explained in my class Diagram.

4. INSTALLATION
Provide instructions on how to install and run the software.
Initially, unzip the zip folder ASM1. Open the folder by IntelliJ.
Configure IntelliJ:
    +Search src folder ../ASM1/src in ASM1 folder -> (right lick) mark directory as -> Resources Root

    +Change working directory: Run-> edit configuration -> Working directory -> change as ../ASM1/src 

    +In case there is lack of "out" directory, create a new one in ../ASM1/ folder as ../ASM1/out

    +In case build does not work, set up JRE manually by :
    run -> Edit Configuration -> JRE: file java 11.* path  ../Library/Java/JavaVirtualMachines/jdk-11.0.7.jdk/Contents/Home/bin/java 
    
    +The main function of the program is located in file ASM1.java
5. KNOWN BUGS
-My foremost shortage is that my program load data at the begining save data after each called function, which means the 9.Save data selection is useless. The reason of this bug is my methods of loading data in my objects. If i saved all at the Save data function at once, there are may be clash between section dataset of each object.


6. ACKNOWLEDGEMENT
-My coding text is self-writed, however i referenced some external source of code to boost my program efficiency, that is:
+ Using ISBN, ISSN and date "regex format" in class ItemList from the website:"regexlib.com"
+ Applied Knowledge from Lecture Slide and reading materials from "w3schools.com" website on coding.